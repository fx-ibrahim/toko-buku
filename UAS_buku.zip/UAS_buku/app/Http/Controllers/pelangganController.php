<?php

namespace App\Http\Controllers;

use App\Models\pelanggan;
use Illuminate\Http\Request;

class pelangganController extends Controller
{
    public function index(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        // validasi: hanya application/json atau application/xml yang valid
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
        $pelanggan = pelanggan::OrderBy("id", "DESC")->paginate(10);

        if ($acceptHeader === 'application/json'){
            //response json
            return response()->json($pelanggan->items('data'), 200);
        } else {
            // create xml pelanggan element
            $xml = new \SimpleXMLElement('<pelanggan/>');
            foreach ($pelanggan->items('data') as $item){
                // create xml pelanggan element
                $xmlItem = $xml->addChild('pelanggan');

                //mengubah setiap field pelanggan menjadi bentuk xml
                $xml->addChild('nama', $item->nama);
                $xml->addChild('alamat', $item->alamat);
                $xml->addChild('no_hp', $item->no_hp);
                $xml->addChild('jumlah_buku', $item->jumlah_buku);
                $xml->addChild('harga', $item->harga);
                $xml->addChild('total', $item->total);
                $xml->addChild('created_at', $item->created_at);
                $xml->addChild('updated_at', $item->updated_at);
            }
            return $xml->asXML();
        }

        //$outPut = [
        //    "message" => "pelanggan",
        //    "results" => $pelanggan
        //];

        return response()->json($pelanggan, 200);
    } else {
        return response('Not Acceptable!', 406);
    }
    }
    public function store(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        //validasi: hanya application/json atau application/xml yang valid
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $contentTypeHeader = $request->header('Content-Type');

            // validasi : hanya application/json yang valid
            if ($contentTypeHeader === 'application/json'){
        $input = $request->all();
        $pelanggan = pelanggan::create($input);

        return response()->json($pelanggan, 200);
    } else {
        return response('Unsupported Media Type', 415);
    }
    }else {
        return response ('Not Accepttable!', 406);
    }
    }
    public function show ($id)
    {
        $pelanggan = pelanggan::find($id);

        if (!$pelanggan){
            abort(400);
        }
        return response()->json($pelanggan, 200);
    }
    public function update (Request $request, $id)
    {
        $input = $request->all();
        $pelanggan = pelanggan::find($id);

        if (!$pelanggan){
            abort(400);
        }

        $pelanggan->fill($input);
        $pelanggan->save();

        return response()->json($pelanggan, 200);
    }
    public function destroy ($id)
    {
        $pelanggan = pelanggan::find($id);

        if(!$pelanggan) {
            abort(404);
        }

        $pelanggan->delete();
        $message = ['messsage' => 'deleted successfully', 'pelanggan_id' => $id];

        return response()->json($message, 200);
    }
}