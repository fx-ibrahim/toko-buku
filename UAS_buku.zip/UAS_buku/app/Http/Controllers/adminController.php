<?php

namespace App\Http\Controllers;

use App\Models\admin;
use Illuminate\Http\Request;

class adminController extends Controller
{
    public function index(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        // validasi: hanya application/json atau application/xml yang valid
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
        $admin = admin::OrderBy("id", "DESC")->paginate(10);

        if ($acceptHeader === 'application/json'){
            //response json
            return response()->json($admin->items('data'), 200);
        } else {
            // create xml admin element
            $xml = new \SimpleXMLElement('<admin/>');
            foreach ($rekammedis->items('data') as $item){
                // create xml admin element
                $xmlItem = $xml->addChild('admin');

                //mengubah setiap field admin menjadi bentuk xml
                $xmlItem->addChild('id_buku', $item->id_buku);
                $xmlItem->addChild('judul_buku', $item->judul_buku);
                $xmlItem->addChild('penerbit_buku', $item->penerbit_buku);
                $xmlItem->addChild('genre_buku', $item->genre_buku);
                $xmlItem->addChild('harga_buku', $item->harga_buku);
                $xmlItem->addChild('created_at', $item->created_at);
                $xmlItem->addChild('updated_at', $item->updated_at);
            }
            return $xml->asXML();
        }

        return response()->json($admin, 200);
    } else {
        return response('Not Acceptable!', 406);
    }
    }
    public function store(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        //validasi: hanya application/json atau application/xml yang valid
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $contentTypeHeader = $request->header('Content-Type');

            // validasi : hanya application/json yang valid
            if ($contentTypeHeader === 'application/json'){
        $input = $request->all();
        $admin = admin::create($input);

        return response()->json($admin, 200);
    } else {
        return response('Unsupported Media Type', 415);
    }
    }else {
        return response ('Not Accepttable!', 406);
    }
    }
    public function show ($id)
    {
        $admin = admin::find($id);

        if (!$admin){
            abort(400);
        }
        return response()->json($admin, 200);
    }
    public function update (Request $request, $id)
    {
        $input = $request->all();
        $admin = admin::find($id);

        if (!$admin){
            abort(400);
        }

        $admin->fill($input);
        $admin->save();
        
        return response()->json($admin, 200);
    }
    public function destroy ($id)
    {
        $admin = admin::find($id);

        if(!$admin) {
            abort(404);
        }

        $admin->delete();
        $message = ['messsage' => 'deleted successfully', 'admin_id' => $id];
        return response()->json($message, 200);
    }
}