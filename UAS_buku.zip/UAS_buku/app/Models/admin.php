<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class admin extends Model
{
    protected $fillable = array('id_buku', 'judul_buku', 'penerbit_buku', 'genre_buku', 'harga_buku');

    public $timestamps = true;
}