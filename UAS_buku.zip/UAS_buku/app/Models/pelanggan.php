<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class pelanggan extends Model
{
    protected $fillable = array('nama', 'alamat', 'no_hp', 'jumlah_buku', 'harga', 'total');

    public $timestamps = true;
}