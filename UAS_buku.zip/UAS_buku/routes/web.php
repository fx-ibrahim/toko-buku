<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});
$router->get('users', 'UsersController@index');

// Pelanggan
Route::group(['middleware' => ['auth']], function ($router){
$router->get('pelanggan', 'pelangganController@index');
$router->get('/pelanggan', 'pelangganController@index');
$router->post('/pelanggan', 'pelangganController@store');
$router->get('/pelanggan/{id}', 'pelangganController@show');
$router->put('/pelanggan/{id}', 'pelangganController@update');
$router->delete('/pelanggan/{id}','pelangganController@destroy');
});


// admin
Route::group(['middleware' => ['auth']], function ($router){
$router->get('admin', 'adminController@index');
$router->get('/admin', 'adminController@index');
$router->post('/admin', 'adminController@store');
$router->get('/admin/{id}', 'adminController@show');
$router->put('/admin/{id}', 'adminController@update');
$router->delete('/admin/{id}','adminController@destroy');
});

// authentication
$router->group(['prefix' => 'auth'], function () use ($router) {
    // Matches "/api/register
    $router->post('/register', 'AuthController@register');
    $router->post('/login', 'AuthController@login');
});